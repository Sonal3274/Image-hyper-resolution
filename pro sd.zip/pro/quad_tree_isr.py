import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
from operator import add
from functools import reduce
from ISR.models import RDN, RRDN
from PIL import Image
from quad_tree_utils import QuadTreeUtil

img = mpimg.imread('./img12.jpg')


class ImageQuadImp:
    def __init__(self):
        self.imagequad_tree = QuadTreeUtil()

    def implement_quad(self, img, level=0):
        a = 0.5
        r = 1.6
        randArray = []
        self.level = level
        self.mean = self.imagequad_tree.calculate_image_mean(img).astype(int)
        self.resolution = (img.shape[0], img.shape[1])
        self.final = True

        if not self.imagequad_tree.quadCheckEqual(img):
            split_img = self.imagequad_tree.split_quads(img)
            self.final = False
            self.north_west = ImageQuadImp().implement_quad(
                split_img[0], level + 1)
            self.north_east = ImageQuadImp().implement_quad(
                split_img[1], level + 1)
            self.south_west = ImageQuadImp().implement_quad(
                split_img[2], level + 1)
            self.south_east = ImageQuadImp().implement_quad(
                split_img[3], level + 1)
        return self

    def get_quad_image(self, level):
        if(self.final or self.level == level):
            return np.tile(self.mean, (self.resolution[0], self.resolution[1], 1))

        return self.imagequad_tree.concatenate_quads(
            self.north_west.get_quad_image(level),
            self.north_east.get_quad_image(level),
            self.south_west.get_quad_image(level),
            self.south_east.get_quad_image(level))


image_quad = ImageQuadImp().implement_quad(img)
quadimage = image_quad.get_quad_image(10)
res_model = RRDN(weights='gans')
low_res_image = np.array(quadimage)
sup_res_image = res_model.predict(low_res_image)
imgg = Image.fromarray(sup_res_image)
imgg
