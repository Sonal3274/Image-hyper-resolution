import unittest
from quad_tree_utils import QuadTreeUtil
from unittest.mock import MagicMock
import matplotlib.image as mpimg
import numpy as np


class TestQuadTreeUtil(unittest.TestCase):
    def setUp(self):
        self.image = mpimg.imread('./img12.jpg')
        self.quad_utils = QuadTreeUtil()
        self.image_np = np.array(self.image)

    def test_quadCheckEqual(self):
        expected = False
        self.assertEqual(
            self.quad_utils.quadCheckEqual(self.image_np), expected)


if __name__ == '__main__':
    unittest.main()
