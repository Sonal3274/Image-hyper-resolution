import unittest
from zoom_in_out import CanvasImage
import tkinter as tk


class TestCanvasImage(unittest.TestCase):
    def setUp(self):
        self.canvimage = CanvasImage(tk.Tk(), './img12.jpg')

    def test_zoom_in(self):
        expected = [[112, 112]]
        self.canvimage.quadrant_manipulation_zoomin(112, 112, 1.3)
        self.assertEqual(self.canvimage.emptylist['clicks'], expected)


if __name__ == '__main__':
    unittest.main()
