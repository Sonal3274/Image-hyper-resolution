import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
from operator import add
from functools import reduce
from ISR.models import RDN, RRDN
from PIL import Image


class QuadTreeUtil:

    def split_quads(self, image):
        half_split = np.array_split(image, 2)
        res = map(lambda x: np.array_split(x, 2, axis=1), half_split)
        return reduce(add, res)

    def concatenate_quads(self, north_west, north_east, south_west, south_east):
        top = np.concatenate((north_west, north_east), axis=1)
        bottom = np.concatenate((south_west, south_east), axis=1)
        return np.concatenate((top, bottom), axis=0)

    def calculate_image_mean(self, img):
        return np.mean(img, axis=(0, 1))

    def quadCheckEqual(self, myList):
        first = myList[0]
        return all((x == first).all() for x in myList)
